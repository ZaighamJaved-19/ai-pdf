"""Page-preserving local retrieval primitives."""

from .retriever import LocalRetriever, RetrievalResult, TextChunk

__all__ = ["LocalRetriever", "RetrievalResult", "TextChunk"]
