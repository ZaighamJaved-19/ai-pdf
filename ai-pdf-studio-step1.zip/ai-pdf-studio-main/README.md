# AI PDF Studio

AI PDF Studio is a privacy-first Windows PDF productivity workspace. Traditional PDF operations are designed to run locally; AI features are provider-backed and require explicit configuration and consent.

## Current status

The repository currently contains the first tested core vertical slice:

- Typed PDF document models.
- Local PDF inspection and page-aware text extraction using `pypdf`.
- SQLite document-library repository for source references and reading position.
- Architecture and delivery documentation.

The Windows UI, OCR, editing, conversion, retrieval, and provider integrations are intentionally staged behind this foundation so they can be implemented with real behavior and tested contracts.

## Development

Requirements: Python 3.11+.

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
python -m pytest
```

The package is structured so a Windows desktop frontend can call the local application services without coupling UI code to PDF parsing or persistence.

## Privacy

No PDF content is uploaded by the core library. Any future AI provider adapter must require explicit user consent before sending document content and must preserve page references in its response contract.

See [`docs/architecture.md`](docs/architecture.md) for the planned module boundaries, security model, and release phases.
